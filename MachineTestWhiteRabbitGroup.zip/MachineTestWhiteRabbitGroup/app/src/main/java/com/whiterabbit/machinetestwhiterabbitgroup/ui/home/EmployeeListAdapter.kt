package com.whiterabbit.machinetestwhiterabbitgroup.ui.home

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import com.bumptech.glide.Glide
import com.whiterabbit.machinetestwhiterabbitgroup.R
import com.whiterabbit.machinetestwhiterabbitgroup.databinding.ItemListBinding
import com.whiterabbit.machinetestwhiterabbitgroup.remote.response.EmployeeResponse

class EmployeeListAdapter(
    private val context: Context,
    val onMainItemClicked: (EmployeeResponse?) -> Unit,
    private val list: List<EmployeeResponse>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)
            : ViewHolder {

        val layoutInflater = LayoutInflater.from(parent.context)
        val itemListBinding: ItemListBinding =
            ItemListBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(itemListBinding)

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ViewHolder).bind(list[position])
        var employee: EmployeeResponse = list[position]
        (holder as EmployeeListAdapter.ViewHolder).bind(employee)
    }


    override fun getItemCount(): Int = list.size


    inner class ViewHolder(binding: ItemListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        private val binding: ItemListBinding = binding
        fun bind(employee: EmployeeResponse): Unit {

            binding.tvName.text = "Name : ${employee.name}"
            if (employee.company?.name.isNullOrEmpty()) {
                binding.tvCompanyName.text = "Company Name : Not Mentioned"
            } else {
                binding.tvCompanyName.text = "Company Name :  ${employee.company?.name}"
            }

            if (employee.profile_image.isNullOrEmpty()) {
                binding.ivProfileImage?.let {
                    Glide.with(context).load(R.drawable.ic_baseline_person_24)
                        .centerCrop()
                        .into(it)
                }
            } else {
                binding.ivProfileImage?.let {
                    Glide.with(context).load(employee.profile_image)
                        .centerCrop()
                        .into(it)
                }
            }

            binding.clEmployeeDetails.setOnClickListener { onMainItemClicked.invoke(employee) }


        }
    }


}