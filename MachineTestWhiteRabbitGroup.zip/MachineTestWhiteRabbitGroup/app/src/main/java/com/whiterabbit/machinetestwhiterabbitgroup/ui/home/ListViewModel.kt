package com.whiterabbit.machinetestwhiterabbitgroup.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.whiterabbit.machinetestwhiterabbitgroup.local.entity.Geo

import dagger.hilt.android.lifecycle.HiltViewModel
import com.whiterabbit.machinetestwhiterabbitgroup.remote.repo.Repository
import com.whiterabbit.machinetestwhiterabbitgroup.remote.response.AddressResponse
import com.whiterabbit.machinetestwhiterabbitgroup.remote.response.CompanyResponse
import com.whiterabbit.machinetestwhiterabbitgroup.remote.response.EmployeeResponse
import com.whiterabbit.machinetestwhiterabbitgroup.remote.response.GeoResponse
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ListViewModel @Inject constructor(private val repository: Repository)
    : ViewModel() {


    private val _categoryList = MutableStateFlow<List<EmployeeResponse>>(listOf())
    val categoryList = _categoryList.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getEmployeeList().collect {
                val mappedList = it.map { employee ->

                    val geoResponse:GeoResponse= GeoResponse(
                        employee.address?.geo?.lat?.toDouble(),
                        employee.address?.geo?.lng?.toDouble(),
                    )
                   val addressResponse= AddressResponse(
                       employee.address?.street,
                       employee.address?.suite,
                       employee.address?.city,
                       employee.address?.zipcode,
                       geoResponse,
                   )

                    val companyResponse=CompanyResponse(
                        employee.company?.name,
                        employee.company?.catchPhrase,
                        employee.company?.bs
                    )
                    EmployeeResponse(
                       employee.id,
                        employee.name,
                        employee.username,
                        employee.email,
                        employee.profile_image,
                        addressResponse,
                        employee.phone,
                        employee.website,
                        companyResponse

                    )
                }

                _categoryList.value = mappedList
            }
        }
    }

}
