package com.whiterabbit.machinetestwhiterabbitgroup.ui.details

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.whiterabbit.machinetestwhiterabbitgroup.databinding.FragmentEmployeeDetailsBinding

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class DetailFragment : Fragment() {

    private var _binding: FragmentEmployeeDetailsBinding? = null
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val args: DetailFragmentArgs by navArgs()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentEmployeeDetailsBinding.inflate(inflater, container, false)
        setUiData()
        binding.ivBack.setOnClickListener {
            findNavController().navigateUp()

        }

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }
    private fun setUiData() {
        args.employeeDetails.let {employee->

            binding.tvEmployeeName.text = "Name: ${employee.name}"
            binding.tvEmployeeUSerName.text = "User Name: ${employee.username}"
            binding.tvEmployeeEmail.text = "Email Id: ${employee.email}"
            binding.tvEmployeeAddress.text = "Address: ${employee.address?.city} , ${employee.address?.street} , ${employee.address?.zipcode}"
            binding.tvEmployeePhone.text = "Phone: ${employee.phone}"
            binding.tvEmployeeWebsite.text = "Website: ${employee.website}"
            binding.tvEmployeeCompany.text = "Company Name: ${employee.company?.name}"


            binding.ivEmployeeImage.let {
                Glide.with(requireContext()).load(employee.profile_image)
                    .centerCrop()
                    .into(it)
            }
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}