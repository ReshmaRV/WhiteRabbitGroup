package com.whiterabbit.machinetestwhiterabbitgroup.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.whiterabbit.machinetestwhiterabbitgroup.local.entity.EmployeeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MachineTestWRGDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertData(data: List<EmployeeEntity>)

    @Query("SELECT * FROM employee_table")
    fun getEmployeeList(): Flow<List<EmployeeEntity>>
}
