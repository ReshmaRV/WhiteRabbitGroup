package com.whiterabbit.machinetestwhiterabbitgroup.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.whiterabbit.machinetestwhiterabbitgroup.local.MachineTestWRGDao
import com.whiterabbit.machinetestwhiterabbitgroup.local.entity.EmployeeEntity

@Database(
    entities = [EmployeeEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MachineTestWRGDatabase : RoomDatabase() {
    abstract fun machineTestDao(): MachineTestWRGDao
}
