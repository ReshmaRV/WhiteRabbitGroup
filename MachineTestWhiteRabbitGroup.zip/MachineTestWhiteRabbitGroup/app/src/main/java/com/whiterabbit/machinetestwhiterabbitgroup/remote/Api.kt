package com.whiterabbit.machinetestwhiterabbitgroup.remote

import com.whiterabbit.machinetestwhiterabbitgroup.remote.response.EmployeeResponse
import com.whiterabbit.machinetestwhiterabbitgroup.utils.network.ApiResponse
import kotlinx.coroutines.flow.Flow
import retrofit2.http.GET
import retrofit2.http.Query

interface Api {
    @GET("v2/5d565297300000680030a986")
    fun getData(
    ): Flow<ApiResponse<List<EmployeeResponse>>>
}
