package com.whiterabbit.machinetestwhiterabbitgroup.local.entity

import androidx.room.ColumnInfo

data class Geo(
    @ColumnInfo(name = "lat")
    var lat: String?,
    @ColumnInfo(name = "lng")
    var lng: String?,
) {
}

