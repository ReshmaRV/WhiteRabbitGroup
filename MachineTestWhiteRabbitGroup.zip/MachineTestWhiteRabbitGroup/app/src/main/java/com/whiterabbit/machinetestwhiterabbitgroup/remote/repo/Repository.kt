package com.whiterabbit.machinetestwhiterabbitgroup.remote.repo


import com.whiterabbit.machinetestwhiterabbitgroup.remote.Api
import com.whiterabbit.machinetestwhiterabbitgroup.local.MachineTestWRGDao
import com.whiterabbit.machinetestwhiterabbitgroup.local.entity.EmployeeEntity
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Repository @Inject constructor(private val api: Api,
                                     private val dao: MachineTestWRGDao
) {

    fun fetchData() = api.getData()

    suspend fun insertData(data: List<EmployeeEntity>) {
        return dao.insertData(data)
    }

    fun getEmployeeList() = dao.getEmployeeList()
}
