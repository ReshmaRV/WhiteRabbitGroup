package com.whiterabbit.machinetestwhiterabbitgroup.ui.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.asLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.whiterabbit.machinetestwhiterabbitgroup.databinding.FragmentEmployeeListBinding
import com.whiterabbit.machinetestwhiterabbitgroup.remote.response.EmployeeResponse
import com.whiterabbit.machinetestwhiterabbitgroup.utils.ListPaddingDecoration
import com.whiterabbit.machinetestwhiterabbitgroup.utils.Utils.safeNavigate
import dagger.hilt.android.AndroidEntryPoint


/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */

@AndroidEntryPoint
class EmployeeListFragment : Fragment() {

    private var _binding: FragmentEmployeeListBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val viewModel: ListViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentEmployeeListBinding.inflate(inflater, container, false)
        setupObservables()

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupObservables() {
        viewModel.categoryList.asLiveData().observe(viewLifecycleOwner) {
            val adapter = EmployeeListAdapter(
                requireContext(),
                this::onRecyclerMainItemClicked, it
            )
            binding.rvEmployeeList.layoutManager = LinearLayoutManager(
                context,
                RecyclerView.VERTICAL, false
            )
            binding.rvEmployeeList.addItemDecoration(
                ListPaddingDecoration(
                    requireContext(),
                    5,
                    0
                )
            )
            binding.rvEmployeeList.adapter = adapter
        }

    }

    private fun onRecyclerMainItemClicked(employee: EmployeeResponse?) {
        employee?.let {
            openDetailPage(it)
        }
    }

    private fun openDetailPage(
        employee: EmployeeResponse
    ) {
        safeNavigate(
            EmployeeListFragmentDirections.actionEmployeeListToEmployeeDetails(employee)
        )
    }
}